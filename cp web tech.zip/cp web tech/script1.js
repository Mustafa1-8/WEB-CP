/**
 * ===================================================================
 * PORTFOLIO JAVASCRIPT - WEB TECHNOLOGIES ASSIGNMENT
 * Features:
 * - Theme Switcher (Dark / Light mode with localStorage)
 * - Mobile Navigation Menu & Backdrop Click
 * - Typing Text Animation
 * - Active Section Scroll Spy
 * - Animated Statistics Counter & Skill Progress Bars
 * - Project Filter System
 * - Form Validation & Feedback Simulation
 * ===================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
  initThemeToggle();
  initMobileNavigation();
  initTypingEffect();
  initScrollSpy();
  initAnimatedCounters();
  initSkillBars();
  initProjectFilters();
  initContactForm();
  initBackToTop();
  updateFooterYear();
});

/* ------------------- 1. THEME SWITCHER (DARK / LIGHT) ------------------- */
function initThemeToggle() {
  const themeToggleBtn = document.getElementById('theme-toggle');
  const root = document.documentElement;

  // Retrieve saved preference or default to 'dark'
  const savedTheme = localStorage.getItem('portfolio-theme') || 'dark';
  root.setAttribute('data-theme', savedTheme);

  themeToggleBtn.addEventListener('click', () => {
    const currentTheme = root.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

    root.setAttribute('data-theme', newTheme);
    localStorage.setItem('portfolio-theme', newTheme);
  });
}

/* ------------------- 2. MOBILE NAVIGATION ------------------- */
function initMobileNavigation() {
  const hamburgerBtn = document.getElementById('hamburger-btn');
  const navMenu = document.getElementById('nav-menu');
  const navLinks = document.querySelectorAll('.nav-link');

  function toggleMenu() {
    const isOpen = navMenu.classList.toggle('open');
    hamburgerBtn.classList.toggle('active');
    hamburgerBtn.setAttribute('aria-expanded', isOpen);
  }

  function closeMenu() {
    navMenu.classList.remove('open');
    hamburgerBtn.classList.remove('active');
    hamburgerBtn.setAttribute('aria-expanded', 'false');
  }

  hamburgerBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleMenu();
  });

  // Close when clicking any nav link
  navLinks.forEach(link => {
    link.addEventListener('click', closeMenu);
  });

  // Close when clicking outside of the navbar
  document.addEventListener('click', (e) => {
    if (!navMenu.contains(e.target) && !hamburgerBtn.contains(e.target)) {
      closeMenu();
    }
  });
}

/* ------------------- 3. TYPING EFFECT IN HERO ------------------- */
function initTypingEffect() {
  const typingElement = document.getElementById('typing-text');
  if (!typingElement) return;

  const roles = [
    'Responsive Web Apps',
    'Interactive UI / UX',
    'Clean Frontend Code',
    'Full-Stack Projects'
  ];

  let roleIndex = 0;
  let charIndex = 0;
  let isDeleting = false;
  const typingSpeed = 100;
  const deletingSpeed = 50;
  const pauseBetween = 1800;

  function type() {
    const currentRole = roles[roleIndex];

    if (isDeleting) {
      typingElement.textContent = currentRole.substring(0, charIndex - 1);
      charIndex--;
    } else {
      typingElement.textContent = currentRole.substring(0, charIndex + 1);
      charIndex++;
    }

    let delay = isDeleting ? deletingSpeed : typingSpeed;

    if (!isDeleting && charIndex === currentRole.length) {
      delay = pauseBetween;
      isDeleting = true;
    } else if (isDeleting && charIndex === 0) {
      isDeleting = false;
      roleIndex = (roleIndex + 1) % roles.length;
      delay = 400;
    }

    setTimeout(type, delay);
  }

  type();
}

/* ------------------- 4. SCROLL SPY (ACTIVE NAV LINK) ------------------- */
function initScrollSpy() {
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');

  function highlightNavOnScroll() {
    const scrollY = window.pageYOffset + 120;

    sections.forEach(current => {
      const sectionHeight = current.offsetHeight;
      const sectionTop = current.offsetTop;
      const sectionId = current.getAttribute('id');

      if (scrollY >= sectionTop && scrollY < sectionTop + sectionHeight) {
        navLinks.forEach(link => {
          link.classList.remove('active');
          if (link.getAttribute('href') === `#${sectionId}`) {
            link.classList.add('active');
          }
        });
      }
    });
  }

  window.addEventListener('scroll', highlightNavOnScroll, { passive: true });
}

/* ------------------- 5. ANIMATED STATS COUNTER ------------------- */
function initAnimatedCounters() {
  const statNumbers = document.querySelectorAll('.stat-number');
  let animated = false;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !animated) {
        animated = true;
        statNumbers.forEach(counter => {
          const target = +counter.getAttribute('data-target');
          const duration = 1500;
          const stepTime = 30;
          const totalSteps = duration / stepTime;
          const increment = target / totalSteps;
          let current = 0;

          const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
              counter.textContent = target;
              clearInterval(timer);
            } else {
              counter.textContent = Math.floor(current);
            }
          }, stepTime);
        });
      }
    });
  }, { threshold: 0.4 });

  const statsSection = document.querySelector('.about');
  if (statsSection) {
    observer.observe(statsSection);
  }
}

/* ------------------- 6. ANIMATED SKILL BARS ------------------- */
function initSkillBars() {
  const progressFills = document.querySelectorAll('.progress-fill');
  let animated = false;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !animated) {
        animated = true;
        progressFills.forEach(fill => {
          const percentage = fill.style.getPropertyValue('--skill-pct') || '80%';
          fill.style.width = percentage;
        });
      }
    });
  }, { threshold: 0.25 });

  const skillsSection = document.querySelector('.skills');
  if (skillsSection) {
    observer.observe(skillsSection);
  }
}

/* ------------------- 7. PROJECT FILTER SYSTEM ------------------- */
function initProjectFilters() {
  const filterBtns = document.querySelectorAll('.filter-btn');
  const projectCards = document.querySelectorAll('.project-card');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => {
        b.classList.remove('active');
        b.setAttribute('aria-selected', 'false');
      });
      btn.classList.add('active');
      btn.setAttribute('aria-selected', 'true');

      const filterValue = btn.getAttribute('data-filter');

      projectCards.forEach(card => {
        const cardCategory = card.getAttribute('data-category');
        if (filterValue === 'all' || cardCategory === filterValue) {
          card.classList.remove('hide');
          card.style.opacity = '0';
          card.style.transform = 'scale(0.95)';
          setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'scale(1)';
          }, 50);
        } else {
          card.classList.add('hide');
        }
      });
    });
  });
}

/* ------------------- 8. CONTACT FORM VALIDATION ------------------- */
function initContactForm() {
  const form = document.getElementById('contact-form');
  if (!form) return;

  const nameInput = document.getElementById('name');
  const emailInput = document.getElementById('email');
  const subjectInput = document.getElementById('subject');
  const messageInput = document.getElementById('message');
  const formStatus = document.getElementById('form-status');
  const submitBtn = document.getElementById('submit-btn');

  function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
  }

  function setFieldError(input, errorElementId, message) {
    const errorEl = document.getElementById(errorElementId);
    input.closest('.input-wrapper').classList.add('error');
    errorEl.textContent = message;
  }

  function clearFieldError(input, errorElementId) {
    const errorEl = document.getElementById(errorElementId);
    input.closest('.input-wrapper').classList.remove('error');
    errorEl.textContent = '';
  }

  [
    { input: nameInput, id: 'name-error' },
    { input: emailInput, id: 'email-error' },
    { input: subjectInput, id: 'subject-error' },
    { input: messageInput, id: 'message-error' }
  ].forEach(field => {
    field.input.addEventListener('input', () => {
      clearFieldError(field.input, field.id);
      formStatus.style.display = 'none';
    });
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    let isValid = true;

    // Validate Name
    if (nameInput.value.trim().length < 2) {
      setFieldError(nameInput, 'name-error', 'Please enter your name (at least 2 characters).');
      isValid = false;
    } else {
      clearFieldError(nameInput, 'name-error');
    }

    // Validate Email
    if (!validateEmail(emailInput.value.trim())) {
      setFieldError(emailInput, 'email-error', 'Please enter a valid email address.');
      isValid = false;
    } else {
      clearFieldError(emailInput, 'email-error');
    }

    // Validate Subject
    if (subjectInput.value.trim().length < 3) {
      setFieldError(subjectInput, 'subject-error', 'Subject must be at least 3 characters.');
      isValid = false;
    } else {
      clearFieldError(subjectInput, 'subject-error');
    }

    // Validate Message
    if (messageInput.value.trim().length < 10) {
      setFieldError(messageInput, 'message-error', 'Please enter a message of at least 10 characters.');
      isValid = false;
    } else {
      clearFieldError(messageInput, 'message-error');
    }

    if (!isValid) return;

    // Simulate sending with loading state
    const originalBtnHtml = submitBtn.innerHTML;
    submitBtn.disabled = true;
    submitBtn.innerHTML = `<span>Sending...</span> <i class="fa-solid fa-spinner fa-spin"></i>`;

    setTimeout(() => {
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalBtnHtml;

      formStatus.className = 'form-status success';
      formStatus.textContent = 'Thank you! Your message has been sent successfully.';
      formStatus.style.display = 'block';

      form.reset();

      setTimeout(() => {
        formStatus.style.display = 'none';
      }, 5000);
    }, 1200);
  });
}

/* ------------------- 9. BACK TO TOP BUTTON ------------------- */
function initBackToTop() {
  const backToTopBtn = document.getElementById('back-to-top');
  if (!backToTopBtn) return;

  backToTopBtn.addEventListener('click', (e) => {
    e.preventDefault();
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  });
}

/* ------------------- 10. FOOTER YEAR ------------------- */
function updateFooterYear() {
  const yearElement = document.getElementById('current-year');
  if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
  }
}